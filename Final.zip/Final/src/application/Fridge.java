package application;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;


// the object fridge which stores the recipes
public class Fridge 
{
	// the food is the string added to the list
	private String food; 
	// counter is the counter of how many items it has in it
	int counter = 0;
	// the arraylist of suggestions to be posed to the user
	ArrayList<String> suggestions = new ArrayList<String>();
 
	// no arg constructor
	public Fridge()
	{	}

	// the method to find the recipes from what you have
	public ArrayList<String> findRecipe(ArrayList<String> e)
	{	
		
		//Cooking Sauces Such as Pizza Sauce and other Sauces are not included, also spices such 
		//as salt and pepper.
		
		/* Current Recipes:
		 * 
		 * 1(Glass Of Milk)
		 * 2(Banana Smoothie)
		 * 3(Fried Eggs)
		 * 4(Egg Salad)
		 * 5(French Toast)
		 * 6(Scrambled Eggs)
		 * 7(Fries)
		 * 8(Mashed Potatoe)
		 * 9(Celery Soup)
		 * 10(Cheese Pizza)
		 * 11(Veggie Pizza)
		 * 12(Meat Lovers Pizza)
		 * 13(Tuna Sandwich)
		 * 14(Ham Sandwich)
		 * 15(Veggie Sandwich)
		 * 16(Chicken Fried Rice)
		 * 17(Lasagna)
		 * 18(Spaghetti)
		 * 19(Meatballs)
		 * 20(Cheese Burger)
		 * 21(Butter Chicken W/ Rice)
		 * 22(Eggs n Fries)
		 * 23(Strawberry Banana Smoothie)
		 * 24(Hawaiian Pizza)
		 * 25(Blueberry Milkshake)
		 */
		
		
		// Milk branch
		if(e.contains("milk"))
		{
			suggestions.add("\n(Glass Of Milk); Milk"); 
			
			if(e.contains("blueberries"))
			{
				suggestions.add("\n(Blueberry Milkshake); Milk & Blueberrys");
			}
			
			if(e.contains("strawberries"))
			{
				suggestions.add("\n(Strawberry Smoothie); Milk & Strawberry");
			}
			
			if(e.contains("bananas"))
			{
				suggestions.add("\n(Banana Smoothie); Milk & Bananas");
				
				if(e.contains("blueberries"))
				{
					suggestions.add("\n(Blueberry Milkshake); Milk & Bananas & Blueberrys");
				}
				
				if(e.contains("strawberries"))
				{
					suggestions.add("\n(Strawberry Banana Smoothie); Milk & Bananas & Strawberry");
				}
			}
		}
		
		// Eggs branch
		if(e.contains("eggs"))
		{
			suggestions.add("\n(Fried Eggs); Eggs"); 
			
			if(e.contains("mayonnaise"))
			{
			suggestions.add("\n(Egg Salad); Eggs & Mayonnaise"); 
			}	
			
			if(e.contains("potatoes"))
			{
				if(e.contains("butter"))
				{
				suggestions.add("\n(Eggs n Fries); Eggs & Fries & Butter"); 
				}		
			}
			// milk branch
			if(e.contains("milk"))
			{
				
				if(e.contains("bread"))
				{
					if(e.contains("apples"))
					{
					suggestions.add("\n(French Toast); Eggs & Milk & Bread & Apples");
					}
				}
				if(e.contains("mayonnaise"))
				{

					suggestions.add("\n(Scrambled Eggs); Eggs & Mayonnaise & Milk");
					
				}
			}
		}
		
		//Potatoes Branch
		if(e.contains("potatoes"))
		{
			suggestions.add("\n(Fries); Potatoes");
			suggestions.add("\n(Mashed Potatoe); Potatoes");
		}
		
		//Celery Branch
		if(e.contains("celery"))
		{
			if(e.contains("chicken"))
			{
				if(e.contains("potatoes"))
				{
					if(e.contains("butter"))
					{
						suggestions.add("\n(Celery Soup); Celery & Chicken & Potato & Butter");
					}
				}
			}
		}
		
		//Rice Branch
		if(e.contains("rice"))
		{
			if(e.contains("carrots"))
			{
				if(e.contains("eggs"))
				{
					if(e.contains("chicken"))
					{
						suggestions.add("\n(Chicken Fried Rice); Rice & Carrots & Eggs & Chicken");
					}
				}
			}
		}
		
		//Cheese branch
		if(e.contains("cheese"))
		{	
			if(e.contains("pasta"))
			{	
				if(e.contains("ground beef"))
				{	
					suggestions.add("\n(Lasgna); Cheese & Pasta & Ground Beef"); 
				}
			}
		
			if(e.contains("bread"))
			{
				suggestions.add("\n(Cheese Pizza); Cheese & Bread"); 
			}
			if(e.contains("peppers"))
			{	
				if(e.contains("tomatoes"))
			{
				suggestions.add("\n(Veggie Pizza); Cheese & Bread & Peppers & Tomatoes"); 
			}
			}
		}
		
		// Chicken branch
		if(e.contains("chicken"))
		{
			if(e.contains("pork"))
			{
				if(e.contains("ground beef"))
				{
					if(e.contains("cheese"))
					{
						if(e.contains("bread"))
						{
							suggestions.add("\n(Meat Lovers Pizza); Chicken & Pork & Ground Beef & Cheese & Bread");
						}
					}
				}
			}
		}
		
		//Bread Branch
		if(e.contains("bread"))
		{
			if(e.contains("tomatoes"))
			{
				if(e.contains("peppers"))
				{
					suggestions.add("\n(Veggie Sandwich); Bread & Tomato & Peppers");
				}
			}
		}
		
		//Pasta Branch
		if(e.contains("pasta"))
		{
			if(e.contains("ground beef"))
			{
				if(e.contains("peppers"))
				{
					if(e.contains("tomatoes"))
					{
					suggestions.add("\n(Spaghetti); Pasta & Ground Beef & Peppers & Tomatoes");
					}
				}
			}
		}
		
		// Ground Beef Branch
		if(e.contains("ground beef"))
		{
			if(e.contains("peppers"))
			{
				if(e.contains("eggs"))
				{
				suggestions.add("\n(Meatballs); Pasta & Ground Beef & Peppers & Tomatoes");
				}
			}
		}
		// ground beef branch
		if(e.contains("ground beef"))
		{
			if(e.contains("tomatoes"))
			{
				if(e.contains("cheese"))
				{
					if(e.contains("mayonnaise"))
					{
						if(e.contains("bread"))
						{
							suggestions.add("\n(Cheese Burger); Ground Beef & Tomatoes & Cheese & Mayonnaise & Bread");// 9
						}
					}
				}
			}
		}
				
		//Tuna Branch
		if(e.contains("tuna"))
		{
			if(e.contains("bread"))
			{
				if(e.contains("mayonnaise"))
				{
					suggestions.add("\n(Tuna Sandwich); Tuna & Bread & Mayonnaise");// 9
				}
			}
		}
		
		//Ham Branch
		if(e.contains("ham"))
		{
			if(e.contains("bread"))
			{
				if(e.contains("cheese"))
				{
					suggestions.add("\n(Ham and cheese Sandwich) Ham & Cheese & Bread)");

					if(e.contains("pineapple"))
					{
						suggestions.add("\n(Hawaiian Pizza); Ham & Bread & Cheese & Pineapple"); // 10
					}
				}
			}
			// mayonnaise branch
			if(e.contains("mayonnaise"))
			{
				if(e.contains("bread"))
				{
					suggestions.add("\n(Ham Sandwich); Ham & Mayonnaise & Bread"); // 10
				}
			}
		}
		
		// Chicken Branch
		if(e.contains("chicken"))
		{
			if(e.contains("tomatoes"))
			{
				if(e.contains("rice"))
				{
					if(e.contains("butter"))
					{
						if(e.contains("milk"))
						{
					suggestions.add("\n(Butter Chicken W/ Rice); Chicken & Tomatoes & Rice & Butter & Milk"); 
						}
					}
				}
			}
		}
		// quick change to a hash set to remove duplicates
		Set<String> hs = new HashSet<String>();
		hs.addAll(suggestions);
		suggestions.clear();
		suggestions.addAll(hs);
		
		// if it found nothing, its time to go grocery shopping
		if (e.size() == 0)
		{
			suggestions.add("A trip to the grocery store ");
		}

		return suggestions;
	}
	// getters and setters
	public String getFood()
	{
		return this.food;
	}
	public void setFood(String food)
	{
		this.food = food;
		counter ++;
	}
	public int getCounter()
	{
		return counter;
	}
	public void setCounter(int x)
	{
		this.counter=x;
	}
	
	// custom method to change the way the array is displayed by removing the [ ] and , - put in by default to the arraytostring method
	public String normText(ArrayList<String> e)
	{
		String normie = e.toString().replace("[","").replace("]","").replace(",", "");
		return normie;
	}
	
		
}